:HL["/front/_next/static/chunks/0y.tl.o4gcm1b.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"lq9XGK6bMTeX_b5pCRQro"}
