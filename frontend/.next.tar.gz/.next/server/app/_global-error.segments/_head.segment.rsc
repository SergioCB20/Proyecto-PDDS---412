1:"$Sreact.fragment"
2:I[97367,["/front/_next/static/chunks/01xlw8hd842-c.js","/front/_next/static/chunks/0d3shmwh5_nmn.js"],"ViewportBoundary"]
3:I[97367,["/front/_next/static/chunks/01xlw8hd842-c.js","/front/_next/static/chunks/0d3shmwh5_nmn.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/front/_next/static/chunks/01xlw8hd842-c.js","/front/_next/static/chunks/0d3shmwh5_nmn.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/front/favicon.ico?favicon.0x3dzn~oxb6tn.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"lq9XGK6bMTeX_b5pCRQro"}
