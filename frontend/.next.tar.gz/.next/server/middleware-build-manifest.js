globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/lq9XGK6bMTeX_b5pCRQro/_buildManifest.js",
    "static/lq9XGK6bMTeX_b5pCRQro/_ssgManifest.js",
    "static/lq9XGK6bMTeX_b5pCRQro/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/153iszdhi7ro~.js",
    "static/chunks/0fi3z_kg64g7q.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-0za_14a.v4apx.js"
  ]
};
